from TFIDF import tf_idf_retrival
from Ret_model import fetch_ret_mod
from GoldRetrival import fetch_gold
import solr
import os
from utils import remove_non_ascii, welcome_string, normalize, Document


class TDQFS():
    def __init__(self, solr_servers):
        self.solr_servers = solr_servers

    def __str__(self):
        return 'TD-QFS'

    def get_topics(self):
        return os.listdir('TD-QFS')

    def get_queries(self, topic):
        queries = []
        for line in open('TD-QFS/'+topic+'/queries.txt'):
            queries.append(line.split('|')[0].strip())
        return queries

    def process_solr_hit(self, hit):
        sents = remove_non_ascii(hit['text'][0])
        sents = sents.split("newlinE")
        sents = sents[::2]
        sents = map(lambda sent: welcome_string(sent), sents)
        sents = map(lambda sent: normalize(sent), sents)
        sents = filter(lambda x: x[0], sents)
        return sents

    def fetch_TFIDF_score(self, topic, query, retrieval_size, hier):
        corpus = self.retrieve_all(topic)
        query = welcome_string(query)
        query = normalize(query)
        query = Document([query])
        retrival = tf_idf_retrival(map(lambda doc: Document(doc), corpus), query, retrieval_size)
        retrival = map(lambda doc: (doc[0], doc[1].doc), retrival)
        if hier:
            return retrival
        out = []
        for doc in retrival:
            for sent in doc[1]:
                out.append((doc[0], sent))
        return out


    def fetch_TFIDF(self, topic, query, retrieval_size, hier, just_text = False):
        if just_text:
            out = []
            if retrieval_size == -1:
                query = "*:*"
            retrival = self.fetch_TFIDF_heir(topic, query, retrieval_size)
            for doc in retrival:
                doc = map(lambda sent: sent[0],doc)
                doc = ' '.join(doc)
                out.append(doc)
            return out
        if hier:
            return self.fetch_TFIDF_heir(topic, query, retrieval_size)
        return sum(self.fetch_TFIDF_heir(topic, query, retrieval_size), [])

    def fetch_TFIDF_heir(self, topic, query, retrieval_size):
        if retrieval_size == -1:
            retrieval_size = 1000000
        solr_server = self.solr_servers[topic]
        solr_connection = solr.SolrConnection(solr_server)

        docs = []
        start = 0
        doccount = 0
        response = solr_connection.query(query, start=start)
        while response:
            for hit in response.results:
                doccount += 1
                if doccount > retrieval_size:
                    break
                docs.append(filter(lambda x: x[1], self.process_solr_hit(hit)))

            if doccount > retrieval_size:
                break
            start += 10
            response = solr_connection.query(query, start=start)
        return docs

    def get_query_number(self, topic, query):
        for (line_num, line) in enumerate(open('TD-QFS/'+topic+'/queries.txt')):
            if line.startswith(query):
                return line_num + 1

    def fetch_manual_summaries(self, topic, query):
        query_number = self.get_query_number(topic, query)
        raw_texts = []
        for file_name in os.listdir('TD-QFS/'+topic+'/'+str(query_number)):
            if 'q1' in file_name:
                for line in open('TD-QFS/'+topic+'/'+str(query_number)+'/'+file_name):
                    raw_texts.append(line)
        return normalize(' '.join(raw_texts))

    def fetch_manual_summaries2(self, topic, query):
        tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
        query_number = self.get_query_number(topic, query)
        raw_texts = []
        for file_name in os.listdir('TD-QFS/'+topic+'/'+str(query_number)):
            if 'q1' in file_name:
                for line in open('TD-QFS/'+topic+'/'+str(query_number)+'/'+file_name):
                    raw_texts += tokenizer.tokenize(line)
        from utils import normalize
        return map(lambda sent: normalize(sent), raw_texts)

    def retrieve_all(self, topic):
        solr_server = self.solr_servers[topic]
        solr_connection = solr.SolrConnection(solr_server)

        docs = []
        start = 0
        doccount = 0
        response = solr_connection.query('*:*', start=start)
        while response:
            for hit in response.results:
                doccount += 1
                docs.append(self.process_solr_hit(hit))
            start += 10
            response = solr_connection.query('*:*', start=start)
        return docs

    def retrieve(self, topic, query, retrieval_model, retrieval_size, hier = False):
        if retrieval_model == 'TFIDF':
            return self.fetch_TFIDF_score(topic, query, retrieval_size, hier = hier)
        if retrieval_model == 'Ret_mod':
            all = self.fetch_TFIDF(topic, "*:*", 100000, hier = True)
            return fetch_ret_mod(all, normalize(query), retrieval_size)
        if retrieval_model == 'Gold':
            return fetch_gold(self.fetch_TFIDF(topic, "*:*", 100000, hier = True), query, retrieval_size, self.fetch_manual_summaries(topic, query), hier = hier)

if __name__ == '__main__':
    solr_servers_dict = {}
    solr_servers_dict['asthma'] = 'http://www.cs.bgu.ac.il/~talbau/solr/'
    solr_servers_dict['cancer'] = 'http://www.cs.bgu.ac.il/~talbau/solrcancer/'
    solr_servers_dict['obese'] = 'http://www.cs.bgu.ac.il/~talbau/solrobese/'
    solr_servers_dict['alz'] = 'http://www.cs.bgu.ac.il/~talbau/solralz/'
    for dataset in [TDQFS(solr_servers_dict)]:
        for topic in dataset.get_topics():
            for query in dataset.get_queries(topic):
                ret3 = dataset.retrieve(topic, query, 'Gold', 5)
                print ret3
                ret1 = dataset.retrieve(topic, query, 'TFIDF', 5)
                print ret1
                ret2 = dataset.retrieve(topic, query, 'Ret_mod', 5)
                print ret2
