from nltk.probability import MLEProbDist
from nltk.probability import FreqDist
from itertools import combinations
from sys import maxint
import math
import copy
from collections import defaultdict


class UnigramDist:

    #text is a list of sentence(=list of words)
    #returm MLEProbDist
    def getUnigramDist(self, text):
        text = sum(text, [])
        word_freq_dist=FreqDist()
        for word in text:
            word_freq_dist[word] += 1
        return MLEProbDist(word_freq_dist)

    def unigramDist_dic(self, text):
        UDdic={}
        mle=self.getUnigramDist(text)
        for sample in mle.samples():
            UDdic[sample]=mle.prob(sample)
        return UDdic

def absolute_discounting(P, Q):
    #init:
    eps = 0.00001
    SP = P.samples()
    CP = len(SP)
    SQ = Q.samples()
    CQ = len(SQ)
    SU = set(SP).union(SQ)
    CU = len(SU)

    Ptag={}
    Qtag={}
    #coputing:
    pc = eps*(CU-CP)/CP
    qc = eps*(CU-CQ)/CQ
    for sample in SU:
        if sample in SP:
            Ptag[sample]=P.prob(sample)-pc
        else:
            Ptag[sample]=eps
        if sample in SQ:
            Qtag[sample]=Q.prob(sample)-qc
        else:
            Qtag[sample]=eps
    return [Ptag,Qtag]

# P & Q of type MLEProbDist. example: KL(gold,test)>0.
def KL(P,Q):
    P_Qtag=absolute_discounting(P, Q)
    Ptag=P_Qtag[0]
    Qtag=P_Qtag[1]

    kl=0
    for sample in Ptag:
        kl+=Ptag[sample]*math.log(Ptag[sample]/Qtag[sample])
    return kl

def KLSum(corpus, sentences, query, size):
    uDist = UnigramDist()
    sentences_disp = uDist.getUnigramDist(map(lambda sent: sent[1], sentences))
    best_score = maxint
    sentences = copy.copy(sentences)
    summ = []
    while sentences:
        best_sentence = None

        for sentence in sentences:
            if not sentence[1]:
                continue
            if len(sentence[1]) == 1:
                continue
            summ_words = map(lambda sentence: sentence[1], summ + [sentence])
            if not summ_words:
                continue
            summ_uDist = uDist.getUnigramDist(summ_words)
            current_score = KL(sentences_disp, summ_uDist)
            if current_score < best_score:
                best_score = current_score
                best_sentence = sentence

        if not best_sentence:
            return map(lambda sentence: sentence[0], summ)
        if len(' '.join(map(lambda sentence: sentence[0], summ)).split(' ')) > size:
            return map(lambda sentence: sentence[0], summ)

        summ.append(best_sentence)
        sentences.remove(best_sentence)
    return map(lambda sentence: sentence[0], summ)

def Exhustive_KL(corpus, sentences, query, size):
    uDist = UnigramDist()
    sentences_disp = uDist.getUnigramDist(map(lambda sentence: sentence[1], sentences))
    best_score = maxint
    summ = []
    for num_of_sentences_in_summary in xrange(1, len(sentences)):
        for summ in combinations(sentences, num_of_sentences_in_summary):
            if len(' '.join(map(lambda sentence: sentence[0], summ)).split(' ')) > size:
                continue
            current_score = KL(sentences_disp, uDist.getUnigramDist(map(lambda sentence: sentence[1], summ)))
            if current_score < best_score:
                best_score = current_score
                best_summ = summ
    return map(lambda sentence: sentence[0], best_summ)

def Greedy_KL(corpus, sentences, query, size):
    uDist = UnigramDist()
    sentences_disp = uDist.getUnigramDist(map(lambda sentence: sentence[1], sentences))
    sentences = copy.copy(sentences)
    best_score = maxint
    summ = []
    for sentence in sentences:
        current_score = KL(sentences_disp, uDist.getUnigramDist(map(lambda sentence: sentence[1], summ + [sentence])))
        if current_score < best_score:
            best_score = current_score
            if len(' '.join(map(lambda sent: sent[0], summ + [sentence])).split(' ')) > size:
                summ = map(lambda sentence: sentence[0], summ)
                return summ
        else:
            print sentence[0]
        summ.append(sentence)

    summ = map(lambda sentence: sentence[0], summ)
    return summ


def normelize_relevance(corpus):
    sum_of_scores = 0.0
    corpus = map(lambda (score, doc): (score, doc), corpus)
    for doc in corpus:
        sum_of_scores += doc[0]
    return map(lambda (score, document): (score/sum_of_scores, document), corpus)


def get_words_in_doc(doc):
    num_of_words = 0.0
    for sent in doc:
        for word in sent[1]:
            num_of_words += 1.0
    return num_of_words


def gen_senteces(corpus):
    sentences = []
    for (score, doc) in corpus:
        for sent in doc:
            sentences.append((sent[0], sent[1], score, doc))
    return sentences


def generate_summary_model_unigram(summ):
    model = defaultdict(lambda: 0.0)
    num_of_words = sum(map(lambda x: len(x[1]), summ))
    for sent in summ:
        for word in sent[1]:
            model[word] += 1.0/num_of_words
    return model


def KL2(P,Q):
    kl = 0.0
    for sample in P:
        if P[sample]:
            if Q[sample]:
                kl+=P[sample]*math.log(P[sample]/Q[sample])
    return kl



def generate_corpus_model(corpus):
    model = defaultdict(lambda: 0.0)
    for (score, doc) in corpus:
        words_in_doc = get_words_in_doc(doc)
        for sent in doc:
            for word in sent[1]:
                model[word] += score/words_in_doc
    return model


def RelSentSum(corpus, size=250):
    corpus = filter(lambda doc: doc[0], corpus)
    corpus = map(lambda doc: (doc[0], doc[1]), corpus)
    corpus = normelize_relevance(corpus)

    corpus_model = generate_corpus_model(corpus)
    sentences = gen_senteces(corpus)


    best_score = maxint
    summ = []
    while True:

        best_sentence = None

        for sentence in sentences:
            if not sentence[1]:
                continue
            #summ_model = generate_summary_model(summ + [sentence])
            summ_model = generate_summary_model_unigram(summ + [sentence])
            current_score = KL2(summ_model, corpus_model)
            if current_score < best_score:
                best_score = current_score
                best_sentence = sentence

                #if not best_sentence:
                #return map(lambda sentence: sentence[0], summ)
        if len(' '.join(map(lambda sentence: sentence[0], summ)).split(' ')) > size:
            break
        if not best_sentence:
            break
        summ.append(best_sentence)
        if best_sentence in sentences:
            sentences.remove(best_sentence)
        best_score = maxint
    return map(lambda sentence: sentence[0], summ)