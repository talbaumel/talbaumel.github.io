from collections import defaultdict
from math import log, sqrt


def gen_idf(corpus):
    idf = defaultdict(lambda : 0)
    N = len(corpus)
    for doc in corpus:
        for word in doc.words:
            idf[word] += 1.0
    for key in idf.keys():
        idf[key] = log(N/idf[key], 2)
    return idf


def gen_tf_idf_vector(doc, idf):
    tf_idf_vector = defaultdict(lambda: 0.0)
    for word in doc.words:
        tf_idf_vector[word] = doc.tf[word]*idf[word]
    return tf_idf_vector


def vector_abs(vector):
    value = 0.0
    for key in vector.keys():
        value += vector[key]**2
    return sqrt(value)


def cosine_similarity(doc1, doc2, idf):
    tf_idf_vector1 = gen_tf_idf_vector(doc1, idf)
    tf_idf_vector2 = gen_tf_idf_vector(doc2, idf)

    return sum(map(lambda key: (tf_idf_vector1[key]*tf_idf_vector2[key]) / (vector_abs(tf_idf_vector1) * vector_abs(tf_idf_vector2)), list(set(tf_idf_vector1.keys()+tf_idf_vector2.keys()))))


def tf_idf_retrival(corpus, query, size):
    idf = gen_idf(corpus)
    scores = map(lambda doc: (cosine_similarity(doc, query, idf), doc), corpus)
    scores = sorted(scores, reverse=True)
    return scores[:size] #map(lambda doc: doc[1], scores[:size])