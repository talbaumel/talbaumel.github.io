from KL_based import KLSum, RelSentSum
from retrieve import TDQFS
from nltk import FreqDist, LaplaceProbDist
from numpy import log2

def KL_summarize(corpus, sentences, query, size=250):
    sentences = map(lambda x: x[1], sentences)
    return KLSum(corpus, sentences, query, size)



def KL_div(doc1, doc2):
    kl_score = 0.0
    pd1 = LaplaceProbDist(FreqDist(sum(map(lambda x: x[1], doc1), [])))
    pd2 = LaplaceProbDist(FreqDist(sum(map(lambda x: x[1], doc2), [])))
    for key in pd1._freqdist.keys():
        kl_score += pd1.prob(key)*log2(pd1.prob(key)/pd2.prob(key))
    return kl_score


def kltreshold(corpus, sentences, query, threshold=0.5, size=250):
    prevscore = 0
    docs = []
    for score, sent in sentences:
        if score == prevscore:
            docs[-1].append(sent)
        else:
            docs.append([sent])
        prevscore = score

    ret = docs[0]
    for i in range(1, len(docs)):
        score = KL_div(ret, docs[i])
        if score <= threshold:
            break
        else:
            ret += docs[i]
            i += 1
    return KLSum(corpus, ret, query, size)


def relsum(corpus, sentences, query, size=250):
    prevscore = 0
    docs = []
    for score, sent in sentences:
        if score == prevscore:
            docs[-1][1].append(sent)
        else:
            docs.append((score, [sent]))
        prevscore = score
    return RelSentSum(docs)

if __name__ == '__main__':
    solr_servers_dict = {}
    solr_servers_dict['asthma'] = 'http://www.cs.bgu.ac.il/~talbau/solr/'
    solr_servers_dict['cancer'] = 'http://www.cs.bgu.ac.il/~talbau/solrcancer/'
    solr_servers_dict['obese'] = 'http://www.cs.bgu.ac.il/~talbau/solrobese/'
    solr_servers_dict['alz'] = 'http://www.cs.bgu.ac.il/~talbau/solralz/'
    for dataset in [TDQFS(solr_servers_dict)]:
        for topic in dataset.get_topics():
            #corpus = dataset.retrieve_all(topic)
            for query in dataset.get_queries(topic):
                print query
                #ret = dataset.retrieve(topic, query, 'TFIDF', 5)
                #print relsum(corpus, ret, query)
                #print kltreshold(corpus, ret, query)
                #print KL_summarize(corpus, ret, query)
