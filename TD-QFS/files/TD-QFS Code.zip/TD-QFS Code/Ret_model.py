from __future__ import division
from utils import Document
from TFIDF import tf_idf_retrival
from numpy import mean
from numpy import log10
from nltk import FreqDist, SimpleGoodTuringProbDist


def prod(l):
    return reduce(lambda x, y: x*y, l, 0.99)


def gen_docs(docs):
    return map(lambda doc: Document(doc), docs)

class RetModel2:
    def __init__(self, docs, query, size,model_size, lmd = 0.7):
        self.original_docs = docs
        self.docs = gen_docs(docs)
        self.query = Document([query])
        models_docs = tf_idf_retrival(self.docs, self.query, model_size)
        models_docs = map(lambda x:x[1],models_docs )
        self.models = self.gen_models(models_docs)
        self.size = size
        self.lmd = lmd

    def gen_models(self, models_docs):
        models = []
        for doc in models_docs:
            model = FreqDist()
            for word in doc.flat_doc:
                model[word] += 1
            models.append(SimpleGoodTuringProbDist(model))
        return models

    def retrive(self):
        scored_docs = map(lambda doc: (self.get_score(doc), doc), self.docs)
        return sorted(scored_docs, reverse=True)[:self.size]

    def get_score(self, doc):
        query_count = 0.0
        for query_word in self.query.words:
            #query_count += log10(1+doc.flat_doc.count(query_word)/len(doc.flat_doc))
            query_count += doc.flat_doc.count(query_word)/len(doc.flat_doc)
        query_score = query_count
        model_score = 0.0
        for model in self.models:
            word_probs = map(lambda word: model.prob(word), doc.flat_doc)
            socres_prods = prod(word_probs)
            model_score += socres_prods**(1.0/len(doc.flat_doc))
        model_score = model_score/len(self.models)
        score = query_score*self.lmd + model_score*(1-self.lmd)
        return score


class RetModel:
    def __init__(self, docs, query, size, model_size, lmd = 0.4):
        self.original_docs = docs
        self.docs = gen_docs(docs)
        self.query = Document([query])
        self.M = tf_idf_retrival(self.docs, self.query, model_size)
        self.size = size
        self.lmd = lmd

    def retrive(self):
        scores = sorted(map(lambda doc: (self.P_D_given_R(doc, self.query), doc), self.docs), reverse=True)
        return scores[:self.size]

    def P_Mi(self, Mi):
        return 1.0/len(self.M)

    def tf(self, w, d):
        return d.tf[w]

    def P_D_given_R(self, D, q):
        scores = map(lambda w: self.P_w_q1_to_qk(w, q), D.words)
        return mean(scores)

    def P_w_q1_to_qk(self, w, q):
        out = self.P_w(w)
        #for qi in q.words:
            #out = out * sum(map(lambda m: self.P_Mi_given_w(m, w)*self.P_w_given_MD(qi, m), self.M))
        return out

    def P_w(self, w):
        return sum(map(lambda m: self.P_w_given_MD(w, m)*self.P_Mi(m), self.M))

    def P_w_given_MD(self, w, D):
        return self.lmd*D.tf[w]/sum(map(lambda v: D.tf[v], D.words))

    def P_Mi_given_w(self, Mi, w):
        return self.P_w_given_MD(w, Mi)*self.P_w(w)/self.P_Mi(Mi)


def fetch_ret_mod(docs, query, size, just_text = False):
    model_size = int(size*0.1)
    if model_size == 0: model_size = 1
    ret_model = RetModel2(docs, query, size, model_size)
    retrived_doc = ret_model.retrive()
    if just_text:
        return map(lambda doc: ' '.join(map(lambda line: line[0], doc.doc)), retrived_doc)
    peeled_docs = map(lambda doc: (doc[0], doc[1].doc), retrived_doc)
    out = []
    for doc in peeled_docs:
        for sent in doc[1]:
            out.append((doc[0], sent))
    return out