from sys import maxint
from KL_based import UnigramDist, KL

def fetch_gold(corpus, query, retrieval_size, manual_summaries, just_text = False, hier = False):
    if retrieval_size == -1:
        return sum(corpus, [])
    uDist = UnigramDist()
    manual_sum_disp = uDist.getUnigramDist([manual_summaries[1]])
    retrival = []
    text = []
    while corpus:
        best_score = maxint
        best_doc = None

        for doc in corpus:
            if retrival:
                pass
            retrival_words = map(lambda d: d[1], sum(map(lambda x:x[1], retrival), []) + doc)
            if not retrival_words:
                continue
            if tuple in map(lambda i: type(i), retrival_words):
                pass
            retrival_uDist = uDist.getUnigramDist(retrival_words)
            current_score = KL(manual_sum_disp, retrival_uDist)
            if current_score < best_score:
                best_score = current_score
                best_doc = (best_score, doc)
        if len(text) + 1 > retrieval_size:
            break
        if not corpus:
            break
        if len(corpus) == 1:
            pass
        text.append(best_doc)
        retrival.append(best_doc)
        corpus.remove(best_doc[1])

    if just_text:
        return map(lambda doc: ' '.join(map(lambda item: item[0], doc)), text)


    if hier:
        return retrival
    out = []
    for doc in retrival:
        for sent in doc[1]:
            out.append((doc[0], sent))
    return out