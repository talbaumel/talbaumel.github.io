import numpy as np
import random


'''
sampling lag (?)
'''
THIN_INTERVAL = 20

'''
burn-in period
'''
BURN_IN = 100

'''
max iterations
'''
ITERATIONS = 1000

class LdaGibbsSampler:
    def __init__(self, documents, V, newdocs, olddocs):
        self.newdocs = newdocs
        self.olddocs = olddocs
        '''
        document data (term lists)
        '''
        self.documents = documents
        '''
        vocabulary size
        '''
        self.V = V
        '''
        number of topics
        '''
        self.K = 4 + len(documents)
        '''
        Dirichlet parameter (document--topic associations)
        '''
        self.alpha = 2.0

        '''
        topic assignments for each word. (doc,word in doc)
        '''
        self.Z = None

        '''
        cwt[i][j] number of instances of word i (term?) assigned to topic j.
        '''
        self.nw = None

        '''
        na[i][j] number of words in document i assigned to topic j.
        '''
        self.nd = None
        '''
        nwsum[j] total number of words assigned to topic j.
        '''
        self.nwsum = None

        '''
        nasum[i] total number of words in document i.
        '''
        self.ndsum = None
        '''
        cumulative statistics of theta
        '''
        self.thetasum = None

        '''
        cumulative statistics of phi
        '''
        self.phisum = None

        '''
        size of statistics
        '''
        self.numstats = None
        '''
        sample lag (if -1 only one sample taken)
        '''
        self.SAMPLE_LAG = None

        self.dispcol = 0
    def genTopicsfodocID(self,docID):
        if docID in self.newdocs:
            return [0,1,2,docID+4]
        if docID in self.olddocs:
            return [0,2,3,docID+4]
        return [0,docID+4]   
    def initialState(self):
        self.M = len(self.documents)
        self.nw = np.zeros( (self.V,self.K) )
        self.nd = np.zeros( (self.M,self.K) )
        self.nwsum = np.zeros( (self.K) )
        self.ndsum = np.zeros( (self.M) )
        
        self.Z = []
        for m in xrange(self.M):
            N = len(self.documents[m])
            self.Z.append([])
            for n in xrange(N):
                avilabletopics = self.genTopicsfodocID(m)
                
                topic = avilabletopics[int(random.random()*len(avilabletopics))]
                self.Z[-1].append(topic)
                self.nw[self.documents[m][n]][topic] += 1
                self.nd[m][topic] += 1
                self.nwsum[topic] += 1
            self.ndsum[m] = N
            
    def gibbs(self,alpha = 2.0):
        self.alpha = alpha
        
        if self.SAMPLE_LAG > 0:
            self.thetasum = np.zeros((len(self.documents),self.K))
            phisum = np.zeros((self.K,self.V))
            self.numstats = 0
            
        self.initialState()
        
        for i in xrange(ITERATIONS):
            for m in xrange(len(self.Z)):
                for n in xrange(len(self.Z[m])):
                    topic = self.sampleFullConditional(m, n)
                    self.Z[m][n] = topic
            
            if i < BURN_IN and i%THIN_INTERVAL == 0:
                print "B",
                self.dispcol += 1
                
            if i > BURN_IN and i%THIN_INTERVAL == 0:
                print "S",
                self.dispcol += 1
            
            if i > BURN_IN and self.SAMPLE_LAG > 0 and i% self.SAMPLE_LAG == 0:
                self.updateParams()
                print "|",
                if i % THIN_INTERVAL != 0:
                    self.dispcol += 1
            
            if self.dispcol >= 100:
                print ""
                self.dispcol = 0
    def getpsudo(self, k):
        if k == 0: return 10
        if k == 1 or k == 2 or k == 3: return 15
        return 1
    def sampleFullConditional(self,m,n):
        topic = self.Z[m][n]
        self.nw[self.documents[m][n]][topic] -= 1
        self.nd[m][topic] -= 1
        self.nwsum[topic] -= 1
        self.ndsum[m] -= 1
        
        p = np.zeros((self.K))
        for k in self.genTopicsfodocID(m):
            p[k] = (self.nw[self.documents[m][n]][k] + self.getpsudo(k)) / (self.nwsum[k] + self.V * self.getpsudo(k))
            
        for k in xrange(1,len(p)):
            p[k] += p[k-1]
            
        u = random.random()*p[self.K-1]
        for temp in self.genTopicsfodocID(m):
            if u < p[temp]:
                topic = temp
                break
        

        
        self.nw[self.documents[m][n]][topic]+=1
        self.nd[m][topic]+=1
        self.nwsum[topic]+=1
        self.ndsum[m]+=1

        return topic
    
    def updateParams(self):
        for m in xrange(len(self.documents)):
            for k in xrange(self.K):
                self.thetasum[m][k] += (self.nd[m][k] + self.alpha) / (self.ndsum[m] + self.K * self.alpha)
            
        
        for k in xrange(self.K):
            for w in xrange(self.V):
                self.phisum[k][w] += (self.nw[w][k] + self.getpsudo(k)) / (self.nwsum[k] + self.V * self.getpsudo(k))
            
        
        self.numstats+=1
    
        
    
    
    