import os
import re
import solr
import sys
from  nltk.tokenize.punkt import PunktWordTokenizer
from nltk.stem.porter import *
from LDA import LdaGibbsSampler
from KLSum import KLsum

wordTokenizer = PunktWordTokenizer()
porter_stemmer = PorterStemmer()

def stop_words() :
    return ['a', 'able', 'about', 'above', 'abst', 'accordance',
                  'according', 'accordingly', 'across', 'act', 'actually',
                  'added', 'adj', 'adopted', 'affected', 'affecting', 'affects',
                  'after', 'afterwards', 'again', 'against', 'ah', 'all',
                  'almost', 'alone', 'along', 'already', 'also', 'although',
                  'always', 'am', 'among', 'amongst', 'an', 'and', 'announce',
                  'another', 'any', 'anybody', 'anyhow', 'anymore', 'anyone',
                  'anything', 'anyway', 'anyways', 'anywhere', 'apparently',
                  'approximately', 'are', 'aren', 'arent', 'arise', 'around',
                  'as', 'aside', 'ask', 'asking', 'at', 'auth', 'available',
                  'away', 'awfully', 'b', 'back', 'be', 'became', 'because',
                  'become', 'becomes', 'becoming', 'been', 'before',
                  'beforehand', 'begin', 'beginning', 'beginnings', 'begins',
                  'behind', 'being', 'believe', 'below', 'beside', 'besides',
                  'between', 'beyond', 'biol', 'both', 'brief', 'briefly',
                  'but', 'by', 'c', 'ca', 'came', 'can', 'cannot', "can't",
                  'cause', 'causes', 'certain', 'certainly', 'co', 'com',
                  'come', 'comes', 'contain', 'containing', 'contains',
                  'could', "couldn't", 'd', 'date', 'did', "didn't", 'different',
                  'do', 'does', "doesn't", 'doing', 'done', "don't", 'down',
                  'downwards', 'due', 'during', 'e', 'each', 'ed', 'edu',
                  'effect', 'eg', 'eight', 'eighty', 'either', 'else',
                  'elsewhere', 'end', 'ending', 'enough', 'especially',
                  'et', 'et-al', 'etc', 'even', 'ever', 'every', 'everybody',
                  'everyone', 'everything', 'everywhere', 'ex', 'except', 'f',
                  'far', 'few', 'ff', 'fifth', 'first', 'five', 'fix',
                  'followed', 'following', 'follows', 'for', 'former',
                  'formerly', 'forth', 'found', 'four', 'from', 'further',
                  'furthermore', 'g', 'gave', 'get', 'gets', 'getting', 'give',
                  'given', 'gives', 'giving', 'go', 'goes', 'gone', 'got',
                  'gotten', 'h', 'had', 'happens', 'hardly', 'has', "hasn't",
                  'have', "haven't", 'having', 'he', 'hed', 'hence', 'her',
                  'here', 'hereafter', 'hereby', 'herein', 'heres', 'hereupon',
                  'hers', 'herself', 'hes', 'hi', 'hid', 'him', 'himself',
                  'his', 'hither', 'home', 'how', 'howbeit', 'however',
                  'hundred', 'i', 'id', 'ie', 'if', "i'll", 'im', 'immediate',
                  'immediately', 'importance', 'important', 'in', 'inc',
                  'indeed', 'index', 'information', 'instead', 'into',
                  'invention', 'inward', 'is', "isn't", 'it', 'itd', "it'll",
                  'its', 'itself', "i've", 'j', 'just', 'k', 'keep', 'keeps',
                  'kept', 'keys', 'kg', 'km', 'know', 'known', 'knows', 'l',
                  'largely', 'last', 'lately', 'later', 'latter', 'latterly',
                  'least', 'less', 'lest', 'let', 'lets', 'like', 'liked',
                  'likely', 'line', 'little', "'ll", 'look', 'looking', 'looks',
                  'ltd', 'm', 'made', 'mainly', 'make', 'makes', 'many', 'may',
                  'maybe', 'me', 'mean', 'means', 'meantime', 'meanwhile',
                  'merely', 'mg', 'might', 'million', 'miss', 'ml', 'more',
                  'moreover', 'most', 'mostly', 'mr', 'mrs', 'much', 'mug',
                  'must', 'my', 'myself', 'n', 'na', 'name', 'namely', 'nay',
                  'nd', 'near', 'nearly', 'necessarily', 'necessary', 'need',
                  'needs', 'neither', 'never', 'nevertheless', 'new', 'next',
                  'nine', 'ninety', 'no', 'nobody', 'non', 'none',
                  'nonetheless', 'noone', 'nor', 'normally', 'nos', 'not',
                  'noted', 'nothing', 'now', 'nowhere', 'o', 'obtain',
                  'obtained', 'obviously', 'of', 'off', 'often', 'oh', 'ok',
                  'okay', 'old', 'omitted', 'on', 'once', 'one', 'ones', 'only',
                  'onto', 'or', 'ord', 'other', 'others', 'otherwise', 'ought',
                  'our', 'ours', 'ourselves', 'out', 'outside', 'over',
                  'overall', 'owing', 'own', 'p', 'page', 'pages', 'part',
                  'particular', 'particularly', 'past', 'per', 'perhaps',
                  'placed', 'please', 'plus', 'poorly', 'possible', 'possibly',
                  'potentially', 'pp', 'predominantly', 'present', 'previously',
                  'primarily', 'probably', 'promptly', 'proud', 'provides',
                  'put', 'q', 'que', 'quickly', 'quite', 'qv', 'r', 'ran',
                  'rather', 'rd', 're', 'readily', 'really', 'recent',
                  'recently', 'ref', 'refs', 'regarding', 'regardless',
                  'regards', 'related', 'relatively', 'research',
                  'respectively', 'resulted', 'resulting', 'results', 'right',
                  'run', 's', 'said', 'same', 'saw', 'say', 'saying', 'says',
                  'sec', 'section', 'see', 'seeing', 'seem', 'seemed',
                  'seeming', 'seems', 'seen', 'self', 'selves', 'sent', 'seven',
                  'several', 'shall', 'she', 'shed', "she'll", 'shes', 'should',
                  "shouldn't", 'show', 'showed', 'shown', 'showns', 'shows',
                  'significant', 'significantly', 'similar', 'similarly',
                  'since', 'six', 'slightly', 'so', 'some', 'somebody',
                  'somehow', 'someone', 'somethan', 'something', 'sometime',
                  'sometimes', 'somewhat', 'somewhere', 'soon', 'sorry',
                  'specifically', 'specified', 'specify', 'specifying',
                  'state', 'states', 'still', 'stop', 'strongly', 'sub',
                  'substantially', 'successfully', 'such', 'sufficiently',
                  'suggest', 'sup', 'sure', 't', 'take', 'taken', 'taking',
                  'tell', 'tends', 'th', 'than', 'thank', 'thanks', 'thanx',
                  'that', "that'll", 'thats', "that've", 'the', 'their',
                  'theirs', 'them', 'themselves', 'then', 'thence', 'there',
                  'thereafter', 'thereby', 'thered', 'therefore', 'therein',
                  "there'll", 'thereof', 'therere', 'theres', 'thereto',
                  'thereupon', "there've", 'these', 'they', 'theyd', "they'll",
                  'theyre', "they've", 'think', 'this', 'those', 'thou',
                  'though', 'thoughh', 'thousand', 'throug', 'through',
                  'throughout', 'thru', 'thus', 'til', 'tip', 'to', 'together',
                  'too', 'took', 'toward', 'towards', 'tried', 'tries', 'truly',
                  'try', 'trying', 'ts', 'twice', 'two', 'u', 'un', 'under',
                  'unfortunately', 'unless', 'unlike', 'unlikely', 'until',
                  'unto', 'up', 'upon', 'ups', 'us', 'use', 'used', 'useful',
                  'usefully', 'usefulness', 'uses', 'using', 'usually', 'v',
                  'value', 'various', "'ve", 'very', 'via', 'viz', 'vol',
                  'vols', 'vs', 'w', 'want', 'wants', 'was', "wasn't", 'way',
                  'we', 'wed', 'welcome', "we'll", 'went', 'were', "weren't",
                  "we've", 'what', 'whatever', "what'll", 'whats', 'when',
                  'whence', 'whenever', 'where', 'whereafter', 'whereas',
                  'whereby', 'wherein', 'wheres', 'whereupon', 'wherever',
                  'whether', 'which', 'while', 'whim', 'whither', 'who', 'whod',
                  'whoever', 'whole', "who'll", 'whom', 'whomever', 'whos',
                  'whose', 'why', 'widely', 'willing', 'wish', 'with', 'within',
                  'without', "won't", 'words', 'world', 'would', "wouldn't",
                  'www', 'x', 'y', 'yes', 'yet', 'you', 'youd', "you'll",
                  'your', 'youre', 'yours', 'yourself', 'yourselves', "you've",
                  'z', 'zero',
                  #punctuation marks:
                  '`', "'", '(', ')', ',', '_', ';', ':', '~', '&', '-', '--',
                  '$', '^', '*', #maybe more
                  #added due to word tokenizer:
                  "'s", "'ll", "'t", "'ve", "'m",
                  'doesn', 'don', 'hasn', 'haven', 'isn', 'wasn', 'won', 'weren',
                  'wouldn', 'didn', 'shouldn', 'couldn']

def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

def processSolrHit(hit):
    for key in hit.keys():
        if key != 'score':
            hit[key] = [removeNonAscii(hit[key][0])]
    sents = (str(hit['text'][0])).split("newlinE")
    sents = [re.sub(r'\t+',' ',sent.replace("\'","\\\'").replace("\"","\\\"")).replace("\\","").encode('ASCII') for sent in sents]
    sents = sents[::2]
    return sents

def fetchDocs(solrServer,query,cutoff = 10):
    print query
    s = solr.SolrConnection(solrServer)
    
    docs = []
    start = 0
    doccount = 0
    response = s.query(query,start = start)
    while response:
        for hit in response.results:
            doccount += 1
            docs += [processSolrHit(hit)]
            if doccount > cutoff:
                break
        if doccount > cutoff:
            break
        start += 10
        response = s.query(query,start = start)
    return docs

def tokenizer(senetence):
    senetence = senetence.lower()
    senetence = re.sub(r'[^0-9a-z ]','', senetence)
    return senetence.split(' ')

def getVocabularyMap(docs):
    wordsDict = {}
    idCounter = 0
    for doc in docs:
        for line in doc:
            for word in line:
                if not word in wordsDict.keys():
                    wordsDict[word] = idCounter
                    idCounter += 1
    return wordsDict

def genDocs(wordsDict,alldocs):
    docs = []
    for doc in alldocs:  
        docs.append([])
        for line in doc:
            for word in line:
                docs[-1].append(wordsDict[word])
    return docs

def runLDA(documents, V, newdocs, olddocs):
    print "Latent Dirichlet Allocation using Gibbs Sampling."
    
    lda = LdaGibbsSampler(documents, V, newdocs, olddocs)
    lda.gibbs()
    
    return lda


def getids(alldocs,somedocs):
    indexs = []
    for (i,doc) in enumerate(alldocs):
        for somedoc in somedocs:
            if len(doc) == len(somedoc):
                iseq = True
                for (line1,line2) in zip(doc,somedoc):
                    if not line1 == line2:
                        iseq=False
                        break
                if iseq:
                    indexs.append(i)
    return list(set(indexs))
                
def normalize(alldocs):
    normdocs = []
    for doc in alldocs:
        normdocs.append([])
        for sent in doc:
            norm_words = []
            for word in wordTokenizer.tokenize(sent[:-1]):
                l_word = word.lower()
                if l_word not in stop_words():
                    norm_words += [porter_stemmer.stem(l_word)]
            normdocs[-1].append(norm_words)
    return normdocs


def printtopics(lda,alldocs,alldocsnormalized,newdocs,filename):
    with open(filename+'.txt','w') as f:
        for (i,(doc,docnorm)) in enumerate(zip(alldocs,alldocsnormalized)):
            if i in newdocs:
                offset = 0
                for (sent,norm) in zip(doc,docnorm):
                    for (j,word) in enumerate(norm):
                       f.write("'"+word+"' topic is "+ str(lda.Z[i][offset + j]) +'\n')
                    offset += len(norm)

    


def getSents(query,prev,solrserver):
    alldocs = fetchDocs(solrserver,"*:*",cutoff = 1000000)
    querydocs = fetchDocs(solrserver,query,cutoff = 10)
    prevdocs = [] 
    for q in prev:
        prevdocs += fetchDocs(solrserver,q,cutoff = 10)
    newdocs = getids(alldocs,querydocs)
    olddocs = getids(alldocs,prevdocs)
    alldocsnormalized = normalize(alldocs)
    wordsDict = getVocabularyMap(alldocsnormalized)
    docs = genDocs(wordsDict,alldocsnormalized)
    lda = runLDA(docs,len(wordsDict), newdocs, olddocs)
    
    printtopics(lda,alldocs,alldocsnormalized,newdocs,str(len(prev)))
    
    
    outsents = []
    normout =[]
    for (i,(doc,docnorm)) in enumerate(zip(alldocs,alldocsnormalized)):
        if i in newdocs:
            offset = 0
            for (sent,norm) in zip(doc,docnorm):
                outsents.append(sent)
                normout.append([])
                normout[-1] += norm
                for (j,word) in enumerate(norm):
                    word = wordsDict[word]
                    if (lda.Z[i][offset + j] == 1) or (len(prev) == 0 and lda.Z[i][offset + j] == 2):
                        normout[-1].append(word)
                offset += len(norm)
    return (outsents,normout)

def writeSummry(summary):
    for line in summary:
        if not line[-1] == '.':
            line += '.'
        print line

                        
def main(topic,chain):
	solrServers = {'asthma':'http://www.cs.bgu.ac.il/~talbau/solr/','cancer':'http://www.cs.bgu.ac.il/~talbau/solrcancer/','alz':'http://www.cs.bgu.ac.il/~talbau/solrobese/','obese':'http://www.cs.bgu.ac.il/~talbau/solralz/'}
	
	previousQuries = []
	for query in chain.split('|'):
		query = query.strip()
		sents = getSents(query,previousQuries,solrServers[topic])
		summary = KLsum(sents,250)
		writeSummry(summary)
		previousQuries.append(query)
				

    
