from sys import maxint
import math
from nltk.probability import MLEProbDist
from unigramDist import UnigramDist


def absolute_discounting(P,Q):
    #init:
    eps=0.00001
    SP=P.samples()
    CP=len(SP)
    SQ=Q.samples()
    CQ=len(SQ)
    SU=set(SP).union(SQ)
    CU=len(SU)

    Ptag={}
    Qtag={}
    #coputing:
    pc=eps*(CU-CP)/CP
    qc=eps*(CU-CQ)/CQ
    for sample in SU:
        if sample in SP:
            Ptag[sample]=P.prob(sample)-pc
        else:
            Ptag[sample]=eps
        if sample in SQ:
            Qtag[sample]=Q.prob(sample)-qc
        else:
            Qtag[sample]=eps
    return [Ptag,Qtag]

# P & Q of type MLEProbDist. example: KL(gold,test)>0.
def KL(P,Q):
    P_Qtag=absolute_discounting(P,Q)
    Ptag=P_Qtag[0]
    Qtag=P_Qtag[1]
    
    kl=0
    for sample in Ptag:
        kl+=Ptag[sample]*math.log(Ptag[sample]/Qtag[sample])
    return kl

def KLsum(sentences,L):
    #init:
    S = []
    d = maxint
    
    summary = []
    sents_dic = {}
    length = 0

    original_sents = sentences[0]
    normalized_sents = sentences[1]

    uDist= UnigramDist()
    Pd=uDist.getUnigramDist(normalized_sents)
    while True:
        min_di=maxint  #the divergence of S with the "runner-up" sentence.
        for i,sent in enumerate(normalized_sents):
            if sent == []:
                di = maxint
            else:
                di = KL(uDist.getUnigramDist(S+[sent]),Pd)
            if di < min_di:
                min_di=di
                index = i
                
        if d <= min_di: #Stop if there is no i such that di < d
            print 'get farther'
            break;
        
        length += len(original_sents[index].split())
        if length > L:
            break
        
        S+=[normalized_sents[index]]
        sents_dic[index] = original_sents[index]
        d=min_di
        
    #ordered sentences:
    for key in sorted(sents_dic):
        summary += [sents_dic[key]]
    return summary

