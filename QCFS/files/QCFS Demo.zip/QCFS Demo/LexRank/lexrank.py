# Input:
#    S: array[n] of sentences
#    t: cosine threshold
#    d: damping factor in the range [0.1..0.2]
# Output:
#    L: array[n] of Lexrank scores for the n sentences
from math import log10
from math import sqrt
from nltk.probability import ConditionalFreqDist
from  nltk.tokenize.punkt import PunktWordTokenizer
import sys
class Lexrank():

    def __init__(self,words_count_in_doc,count,file_count):
        self.words_count_in_doc=words_count_in_doc
        self.count=count
        self.num_of_files=file_count
        self._wordTokenizer = PunktWordTokenizer()
        
    def transpose(self,matrix,n):
        new_matrix=dict()
        for i in range(n):
            for j in range(n):
                new_matrix[i,j]=matrix[j,i]
        return new_matrix

    def norm(self,p):
        nor=0;
        for i in range(len(p)):
            nor+=(p[i]*p[i])
        return sqrt(nor)

    def sub_vec(self,p1,p2,n):
        new_p=dict()
        for i in range(n):
            new_p[i]=p1[i]-p2[i]
        return new_p

    def calc(self,matrix,vec):
        new_vec=dict()
        n=len(vec)
        for i in range(n):
            val=0
            for j in range(n):
                val+=vec[j]*matrix[i,j]
            new_vec[i]=val
        return new_vec
        
    def powerMethod(self,m,n,eps):
        p=dict()
        for i in range(n):
            p[i]=1.0/(1.0*n)
        t=0
        delta=sys.maxint
        new_m=self.transpose(m,n)
        temp=p
        while (delta>eps):
            t+=1
            p=self.calc(new_m,temp)
            delta=self.norm(self.sub_vec(p,temp,n))
            temp=p
        return p



    #df=0.85
    #threshold=0.1,0.2,0.3
    #eps=? error tolerance
    #output = vector holding the score For every sentence- choose x sentences with the best score

    def count_num_of_words(self,sents):
        count=0
        for sent in sents:
            count+=len(self._wordTokenizer.tokenize(sent))
        return count
                
    def createSents(self,sentences,scores,count):
        sents=[]
        indexes=[]
        dic=dict()
        temp=dict()
        for i in range(len(scores)):
            dic[scores[i]]=dic.get(scores[i],[])
            dic[scores[i]].append(i)
        current_count=0
        for index in sorted(dic,reverse=True):
            for index2 in dic[index]:
                length=len(sentences[index2].split())
                if (current_count+length>count):
                    break;
                if (temp.get(sentences[index2],True)):
                    indexes+=[index2]
                    current_count+=length
                    temp[sentences[index2]]=False
        for i in sorted(indexes):
            sents+=[sentences[i]]
        return sents
        


    def lexrank(self,sentences,threshold,df):
        real_sentences=sentences[0]
        modify_sents=sentences[1]
        n=len(modify_sents)
        cosineMatrix=dict()
        degree=dict()
        for i in range(n):
            degree[i]=1  
        L=dict()
        for i in range(n):
            for j in range(n):
                cosineMatrix[i,j]=self.idf_modified_cosine(modify_sents[i],modify_sents[j])
                if (cosineMatrix[i,j]>threshold):
                    cosineMatrix[i,j]=1
                    degree[i]=degree.get(i,0)+1;
                else:
                    cosineMatrix[i,j]=0
        for i in range(n):
            for j in range(n):
                cosineMatrix[i,j]=(1.0*df)/(1.0*n) +((1.0*(1-df)*cosineMatrix[i,j])/(1.0*degree[i]))
        return self.createSents(real_sentences,self.powerMethod(cosineMatrix,n,0.001),self.count)

    def get_tf(self,sent,word):
        count=0;
        for w in sent:
            if (w == word):
                count+=1
        return count

    def get_idf_word(self,word):
        count =self.words_count_in_doc.get(word,0)
        if (count==0):
            return 0
        return log10(self.num_of_files/count)
    
    def get_word_in_both_sent(self,s1,s2):
        l=list()
        for word in s1:
            if (self.get_tf(s1,word)>0 and self.get_tf(s2,word)>0):
                if (word not in l):
                    l.append(word)
        return l
        
    def idf_modified_cosine(self,s1,s2):
        sum_mone=0;
        for word in self.get_word_in_both_sent(s1,s2):
            sum_mone+=self.get_tf(s1,word)*self.get_tf(s2,word)*pow(self.get_idf_word(word),2)

        sum_s1_mechane=0;
        sum_s2_mechane=0;
        for word in s1:
            sum_s1_mechane+=pow(self.get_tf(s1,word)*self.get_idf_word(word),2)
        for word in s2:
            sum_s2_mechane+=pow(self.get_tf(s2,word)*self.get_idf_word(word),2)
        sum_s1_mechane=sqrt(sum_s1_mechane)
        sum_s2_mechane=sqrt(sum_s2_mechane)
        if (sum_s1_mechane*sum_s2_mechane==0):
            return 0
        return (1.0*sum_mone)/(sum_s1_mechane*sum_s2_mechane*1.0)
        
