
from docparser import parser
#from KLSum import KLsum
#from sumbasic import sumBasic
from lexrank import Lexrank
import os

mainFolder = "/"
# 10 clusters:
topics = ["asthma", 'alz', 'cancer', 'obese']
words_limit = 250 #try
indexFile = ''


# file_name - need to include folder
# summary - list of string(= original sentence) ALREADY ORDERD.
# REGULAR print!!!
def print_summary(summary):
    for sent in  summary:
        print sent


# IMPORTANT: need to add folders: Basic, KL, Lex before running.
def main(topic, chain):
	chain = chain.strip()
	for i, query in enumerate( chain.split('|')):
		print query
		p = parser(mainFolder, topic, query)
		all_sentences = p.getDocumentSents()

		# Lex rank algfile_nameo:
		lexrank= Lexrank(p.getDocCountForWords(),250,p.get_num_of_files())
		summary3 =lexrank.lexrank(all_sentences,0.3,0.85)
		print_summary(summary3)
		print '-----------------------------------------------------------------------'



