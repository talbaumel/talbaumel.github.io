from KLSum import KLsum,normalize
import re
import os
import solr
#from sumbasic import sumBasic



def getDocumentSents(sentences):
    normalized_sents=[]
    for sent in sentences:
        normalized_sents += [normalize(sent)]
    return [sentences, normalized_sents]

def writeSummry(summary):
    for line in summary:
        if not line[-1] == '.':
            line += '.'
        print line

def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

def processSolrHit(hit):
    
    for key in hit.keys():
        if key != 'score':
            hit[key] = [removeNonAscii(hit[key][0])]
    sents = (str(hit['text'][0])).split("newlinE")
    sents = [re.sub(r'\t+',' ',sent.replace("\'","\\\'").replace("\"","\\\"")).replace("\\","").replace("\\","").encode('ASCII') for sent in sents]
    sents = sents[::2]
    return sents
    #return getDocumentSents(sents)

def fetchDocs(solrServer,query,cutoff = 10):
    s = solr.SolrConnection(solrServer)
    
    docs = []
    start = 0
    doccount = 0
    response = s.query(query,start = start)
    while response:
        for hit in response.results:
            doccount += 1
            docs += processSolrHit(hit)
            if doccount > cutoff:
                break
        if doccount > cutoff:
            break
        start += 10
        response = s.query(query,start = start)
    sents = getDocumentSents(docs)
    return sents

wordLimit = 250
def main(topic, chain):
	solrServers = {'asthma':'http://www.cs.bgu.ac.il/~talbau/solr/','cancer':'http://www.cs.bgu.ac.il/~talbau/solrcancer/','alz':'http://www.cs.bgu.ac.il/~talbau/solrobese/','obese':'http://www.cs.bgu.ac.il/~talbau/solralz/'}


	prevsummary = []
	for query in chain.split('|'):
		query = query.strip()
		docs = fetchDocs(solrServers[topic],query,cutoff = 10)
		newsummary = KLsum(prevsummary,docs,wordLimit)
		writeSummry(newsummary)
		prevsummary += newsummary

