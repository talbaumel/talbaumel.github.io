from nltk.probability import MLEProbDist
from nltk.probability import FreqDist


class UnigramDist:
        
    #text is a list of sentence(=list of words)
    #returm MLEProbDist
    def getUnigramDist(self, text):
        word_freq_dist=FreqDist()
        for word in sum(text, []):
            word_freq_dist[word] = word_freq_dist[word] + 1
        return MLEProbDist(word_freq_dist)

    def unigramDist_dic(self, text):
        UDdic={}
        mle=self.getUnigramDist(text)
        for sample in mle.samples():
            UDdic[sample]=mle.prob(sample)
        return UDdic


#test:
"""    
l=[['books', 'tries'],['try','tables']]
ud=UnigramDist()
dic=ud.unigramDist_dic(l)
print dic
"""
