from sys import maxint
import math
from nltk.probability import MLEProbDist
from unigramDist import UnigramDist
from nltk.tokenize.punkt import PunktWordTokenizer
from nltk.stem.porter import *
from nltk import FreqDist
wordTokenizer = PunktWordTokenizer()
porter_stemmer = PorterStemmer()
stop_words = ['a', 'able', 'about', 'above', 'abst', 'accordance',
                  'according', 'accordingly', 'across', 'act', 'actually',
                  'added', 'adj', 'adopted', 'affected', 'affecting', 'affects',
                  'after', 'afterwards', 'again', 'against', 'ah', 'all',
                  'almost', 'alone', 'along', 'already', 'also', 'although',
                  'always', 'am', 'among', 'amongst', 'an', 'and', 'announce',
                  'another', 'any', 'anybody', 'anyhow', 'anymore', 'anyone',
                  'anything', 'anyway', 'anyways', 'anywhere', 'apparently',
                  'approximately', 'are', 'aren', 'arent', 'arise', 'around',
                  'as', 'aside', 'ask', 'asking', 'at', 'auth', 'available',
                  'away', 'awfully', 'b', 'back', 'be', 'became', 'because',
                  'become', 'becomes', 'becoming', 'been', 'before',
                  'beforehand', 'begin', 'beginning', 'beginnings', 'begins',
                  'behind', 'being', 'believe', 'below', 'beside', 'besides',
                  'between', 'beyond', 'biol', 'both', 'brief', 'briefly',
                  'but', 'by', 'c', 'ca', 'came', 'can', 'cannot', "can't",
                  'cause', 'causes', 'certain', 'certainly', 'co', 'com',
                  'come', 'comes', 'contain', 'containing', 'contains',
                  'could', "couldn't", 'd', 'date', 'did', "didn't", 'different',
                  'do', 'does', "doesn't", 'doing', 'done', "don't", 'down',
                  'downwards', 'due', 'during', 'e', 'each', 'ed', 'edu',
                  'effect', 'eg', 'eight', 'eighty', 'either', 'else',
                  'elsewhere', 'end', 'ending', 'enough', 'especially',
                  'et', 'et-al', 'etc', 'even', 'ever', 'every', 'everybody',
                  'everyone', 'everything', 'everywhere', 'ex', 'except', 'f',
                  'far', 'few', 'ff', 'fifth', 'first', 'five', 'fix',
                  'followed', 'following', 'follows', 'for', 'former',
                  'formerly', 'forth', 'found', 'four', 'from', 'further',
                  'furthermore', 'g', 'gave', 'get', 'gets', 'getting', 'give',
                  'given', 'gives', 'giving', 'go', 'goes', 'gone', 'got',
                  'gotten', 'h', 'had', 'happens', 'hardly', 'has', "hasn't",
                  'have', "haven't", 'having', 'he', 'hed', 'hence', 'her',
                  'here', 'hereafter', 'hereby', 'herein', 'heres', 'hereupon',
                  'hers', 'herself', 'hes', 'hi', 'hid', 'him', 'himself',
                  'his', 'hither', 'home', 'how', 'howbeit', 'however',
                  'hundred', 'i', 'id', 'ie', 'if', "i'll", 'im', 'immediate',
                  'immediately', 'importance', 'important', 'in', 'inc',
                  'indeed', 'index', 'information', 'instead', 'into',
                  'invention', 'inward', 'is', "isn't", 'it', 'itd', "it'll",
                  'its', 'itself', "i've", 'j', 'just', 'k', 'keep', 'keeps',
                  'kept', 'keys', 'kg', 'km', 'know', 'known', 'knows', 'l',
                  'largely', 'last', 'lately', 'later', 'latter', 'latterly',
                  'least', 'less', 'lest', 'let', 'lets', 'like', 'liked',
                  'likely', 'line', 'little', "'ll", 'look', 'looking', 'looks',
                  'ltd', 'm', 'made', 'mainly', 'make', 'makes', 'many', 'may',
                  'maybe', 'me', 'mean', 'means', 'meantime', 'meanwhile',
                  'merely', 'mg', 'might', 'million', 'miss', 'ml', 'more',
                  'moreover', 'most', 'mostly', 'mr', 'mrs', 'much', 'mug',
                  'must', 'my', 'myself', 'n', 'na', 'name', 'namely', 'nay',
                  'nd', 'near', 'nearly', 'necessarily', 'necessary', 'need',
                  'needs', 'neither', 'never', 'nevertheless', 'new', 'next',
                  'nine', 'ninety', 'no', 'nobody', 'non', 'none',
                  'nonetheless', 'noone', 'nor', 'normally', 'nos', 'not',
                  'noted', 'nothing', 'now', 'nowhere', 'o', 'obtain',
                  'obtained', 'obviously', 'of', 'off', 'often', 'oh', 'ok',
                  'okay', 'old', 'omitted', 'on', 'once', 'one', 'ones', 'only',
                  'onto', 'or', 'ord', 'other', 'others', 'otherwise', 'ought',
                  'our', 'ours', 'ourselves', 'out', 'outside', 'over',
                  'overall', 'owing', 'own', 'p', 'page', 'pages', 'part',
                  'particular', 'particularly', 'past', 'per', 'perhaps',
                  'placed', 'please', 'plus', 'poorly', 'possible', 'possibly',
                  'potentially', 'pp', 'predominantly', 'present', 'previously',
                  'primarily', 'probably', 'promptly', 'proud', 'provides',
                  'put', 'q', 'que', 'quickly', 'quite', 'qv', 'r', 'ran',
                  'rather', 'rd', 're', 'readily', 'really', 'recent',
                  'recently', 'ref', 'refs', 'regarding', 'regardless',
                  'regards', 'related', 'relatively', 'research',
                  'respectively', 'resulted', 'resulting', 'results', 'right',
                  'run', 's', 'said', 'same', 'saw', 'say', 'saying', 'says',
                  'sec', 'section', 'see', 'seeing', 'seem', 'seemed',
                  'seeming', 'seems', 'seen', 'self', 'selves', 'sent', 'seven',
                  'several', 'shall', 'she', 'shed', "she'll", 'shes', 'should',
                  "shouldn't", 'show', 'showed', 'shown', 'showns', 'shows',
                  'significant', 'significantly', 'similar', 'similarly',
                  'since', 'six', 'slightly', 'so', 'some', 'somebody',
                  'somehow', 'someone', 'somethan', 'something', 'sometime',
                  'sometimes', 'somewhat', 'somewhere', 'soon', 'sorry',
                  'specifically', 'specified', 'specify', 'specifying',
                  'state', 'states', 'still', 'stop', 'strongly', 'sub',
                  'substantially', 'successfully', 'such', 'sufficiently',
                  'suggest', 'sup', 'sure', 't', 'take', 'taken', 'taking',
                  'tell', 'tends', 'th', 'than', 'thank', 'thanks', 'thanx',
                  'that', "that'll", 'thats', "that've", 'the', 'their',
                  'theirs', 'them', 'themselves', 'then', 'thence', 'there',
                  'thereafter', 'thereby', 'thered', 'therefore', 'therein',
                  "there'll", 'thereof', 'therere', 'theres', 'thereto',
                  'thereupon', "there've", 'these', 'they', 'theyd', "they'll",
                  'theyre', "they've", 'think', 'this', 'those', 'thou',
                  'though', 'thoughh', 'thousand', 'throug', 'through',
                  'throughout', 'thru', 'thus', 'til', 'tip', 'to', 'together',
                  'too', 'took', 'toward', 'towards', 'tried', 'tries', 'truly',
                  'try', 'trying', 'ts', 'twice', 'two', 'u', 'un', 'under',
                  'unfortunately', 'unless', 'unlike', 'unlikely', 'until',
                  'unto', 'up', 'upon', 'ups', 'us', 'use', 'used', 'useful',
                  'usefully', 'usefulness', 'uses', 'using', 'usually', 'v',
                  'value', 'various', "'ve", 'very', 'via', 'viz', 'vol',
                  'vols', 'vs', 'w', 'want', 'wants', 'was', "wasn't", 'way',
                  'we', 'wed', 'welcome', "we'll", 'went', 'were', "weren't",
                  "we've", 'what', 'whatever', "what'll", 'whats', 'when',
                  'whence', 'whenever', 'where', 'whereafter', 'whereas',
                  'whereby', 'wherein', 'wheres', 'whereupon', 'wherever',
                  'whether', 'which', 'while', 'whim', 'whither', 'who', 'whod',
                  'whoever', 'whole', "who'll", 'whom', 'whomever', 'whos',
                  'whose', 'why', 'widely', 'willing', 'wish', 'with', 'within',
                  'without', "won't", 'words', 'world', 'would', "wouldn't",
                  'www', 'x', 'y', 'yes', 'yet', 'you', 'youd', "you'll",
                  'your', 'youre', 'yours', 'yourself', 'yourselves', "you've",
                  'z', 'zero',
                  #punctuation marks:
                  '`', "'", '(', ')', ',', '_', ';', ':', '~', '&', '-', '--',
                  '$', '^', '*', #maybe more
                  #added due to word tokenizer:
                  "'s", "'ll", "'t", "'ve", "'m",
                  'doesn', 'don', 'hasn', 'haven', 'isn', 'wasn', 'won', 'weren',
                  'wouldn', 'didn', 'shouldn', 'couldn']


def normalize(sent):
    norm_words = []
    #sent[:-1] in order to remove the dot at the end of the sentence:
    for word in wordTokenizer.tokenize(sent[:-1]):
        l_word = word.lower()
        if l_word not in stop_words:
            norm_words += [porter_stemmer.stem(l_word)]
    return norm_words

def absolute_discounting(P,Q):
    #init:
    eps=0.00001
    SP=P.samples()
    CP=len(SP)
    SQ=Q.samples()
    CQ=len(SQ)
    SU=set(SP).union(SQ)
    CU=len(SU)

    Ptag={}
    Qtag={}
    #coputing:
    pc=eps*(CU-CP)/CP
    qc=eps*(CU-CQ)/CQ
    for sample in SU:
        if sample in SP:
            Ptag[sample]=P.prob(sample)-pc
        else:
            Ptag[sample]=eps
        if sample in SQ:
            Qtag[sample]=Q.prob(sample)-qc
        else:
            Qtag[sample]=eps
    return [Ptag,Qtag]

# P & Q of type MLEProbDist. example: KL(gold,test)>0.
def KL(P,Q):
    P_Qtag=absolute_discounting(P,Q)
    Ptag=P_Qtag[0]
    Qtag=P_Qtag[1]
    
    kl=0
    for sample in Ptag:
        kl+=Ptag[sample]*math.log(Ptag[sample]/Qtag[sample])
    return kl

def getVocab(sents):
    vocab = []
    for sent in sents:
        vocab += sent
    return vocab

def KLsum(old,sentences,L):
    #init:
    S = []
    d = maxint
    
    summary = []
    sents_dic = {}
    length = 0

    original_sents = sentences[0]
    normalized_sents = sentences[1]
    
    vocab = getVocab(normalized_sents)
    for sent in old:
        normalized_sent = filter(lambda s:s in vocab,normalize(sent))
        S.append(normalized_sent)
        #L += len(sent.split())
    fd = FreqDist()
    S = [getVocab(S)]        
    for w in S[0]:
        fd[w] = fd[w] + 1
    for w in fd:
        fd[w] = int(fd[w]/10)
    S = [[]]
    for w in fd:
        for i in range(fd[w]):
            S[0].append(w)
    
    
    uDist= UnigramDist()
    Pd=uDist.getUnigramDist(normalized_sents)
    while True:
        min_di=maxint  #the divergence of S with the "runner-up" sentence.
        for i,sent in enumerate(normalized_sents):
            if len(sent) > 60:
                continue
            if sent == []:
                di = maxint
            else:
                di = KL(uDist.getUnigramDist(S+[sent]),Pd)
            if di < min_di:
                min_di=di
                index = i
                
        if d <= min_di: #Stop if there is no i such that di < d
            print 'get farther'
            break;
        
        length += len(original_sents[index].split())
        if length > L:
            break
        
        S+=[normalized_sents[index]]
        sents_dic[index] = original_sents[index]
        d=min_di
        
    #ordered sentences:
    for key in sorted(sents_dic):
        summary += [sents_dic[key]]
    return summary

