
import os
import cPickle
scoredict = {} 
def iseq(i,j):
    if i == j: 
        return 1.0
    else: 
        return 0.0

def LSS(H,T,idf,simfunc):
    if len(H) == 0 or len(T) == 0:
        return 0
    LSSsum = 0
    for HWi in H:
        seq = []
        for TWj in T:
            sf = simfunc(HWi,HWi)
            if sf:
                seq.append(simfunc(HWi,TWj)/simfunc(HWi,HWi))
        if len(seq) > 0:
            if HWi in idf.keys():
                LSSsum += max(seq)*idf[HWi]
            else: LSSsum += max(seq)
    return LSSsum/sum(idf[HWi] for HWi in H)


def simScore(s1,s2,idfs,a,b):
    global scoredict
    if (s1.id,s2.id) in scoredict.keys():
        score = scoredict[(s1.id,s2.id)]
        return score[0] + a*score[1] + b*score[2]   
    (wikiIDF,umlsIDF,tokensIDF) = idfs
    tokenScore = LSS(s1.tokens,s2.tokens,tokensIDF,iseq)
    score = (tokenScore,0,0)
    scoredict [(s1.id,s2.id)] = score
    return score[0] + a*score[1] + b*score[2] 



    