import cPickle as pickle
from buildGraph import sentence,simScore,Doc
from numpy import mean
from networkx import pagerank

def getrank(g):
    #init rank vector
    return pagerank(g)

def normalizeGraph(g):
    for n1 in g:
        weightSum = 0
        for n2 in g.neighbors(n1):
            weightSum+=g[n1][n2]['weight']
        for n2 in g.neighbors(n1):
            g[n1][n2]['weight'] = g[n1][n2]['weight']/weightSum
    return g
            