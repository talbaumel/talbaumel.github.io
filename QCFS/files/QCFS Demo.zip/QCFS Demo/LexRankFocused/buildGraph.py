from nltk.tokenize import wordpunct_tokenize
from nltk.corpus import stopwords
from nltk.corpus import wordnet as wn
from stemming.porter2 import stem
import solr
from collections import defaultdict
import networkx as nx
from itertools import combinations
import pickle
import numpy
from scoring import simScore
import sys
def fetchDocs(solrServer,quary,limit = 10):
    s = solr.SolrConnection(solrServer)
    docs = []
    start = 0
    docsCounter = 0
    response = s.query(quary,start = start)
    while response:
        for hit in response.results:
            docs.append(Doc(hit))
            docsCounter += 1
            if docsCounter >= limit:
                start = 100000
                break
        start += 10
        response = s.query('*:*',start = start)   
    sentencesCounter = 0
    sents = []
    for doc in docs:
        for sent in doc.sents:
            sentencesCounter += 1
            sents.append(sent)
    print 'fetched '+str(docsCounter)+' docs and ' +str(sentencesCounter)+ ' sentences'
    return sents

class sentence:
    def __init__(self,(lexical,sentid),doc):
        self.lexical = lexical
        self.doc = doc.id
        self.id = sentid
        self.tokens = self.normalizeSent(lexical)
        self.WIKIterms = []
        self.UMLSterms = []
        #self.verbs = self.getVerbsList()
    
    def getVerbsList(self):
        sent = self.lexical.lower()
        verbs = []
        for token in wordpunct_tokenize(sent):
            if not token in stopwords.words('english'):
                if not token in ['(',')',',','.']:
                    verb = wn.synsets(token,wn.VERB) 
                    if verb:
                        verbs.append(verb[0])
        return verbs
    def normalizeSent(self,sent):
        sent = sent.lower()
        normaliszedSent = []
        for token in wordpunct_tokenize(sent): 
            if not token in stopwords.words('english'):
                if not token in ['(',')',',','.']:
                    
                    norm = wn.synsets(token,wn.VERB)
                    if norm:
                        normaliszedSent.append(norm[0].name.split('.')[0])
                        continue
                    norm = wn.synsets(token,wn.NOUN)
                    if norm:
                        normaliszedSent.append(norm[0].name.split('.')[0])
                        continue
                    norm = wn.synsets(token,wn.ADJ)
                    if norm:
                        normaliszedSent.append(norm[0].name.split('.')[0])
                        continue
                    norm = wn.synsets(token,wn.ADV)
                    if norm:
                        normaliszedSent.append(norm[0].name.split('.')[0])
                        continue
                    #normaliszedSent.append(PorterStemmer().stem_word(token))
                    normaliszedSent.append(stem(token).lower())
        return normaliszedSent
        
    def __repr__(self):
        return self.lexical

def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

class Doc:
    def __init__(self,hit):
        self.id = removeNonAscii(str(hit['id']))
        self.title = removeNonAscii(str(hit['title'][0]))
        self.sents = self.generateSentences((str(removeNonAscii(hit['text'][0]))).split("newlinE"))
        pass


    def generateSentences(self,sents):
        for (i,sent) in enumerate(sents):
            sents[i] = removeNonAscii(sent)
        sents = [sent.replace("\'","\\\'").replace("\"","\\\"").replace('\\','').encode('ASCII') for sent in sents]
        sents = self.genSentPairs(sents)
        sents = [(s[0],s[1]) for s in sents][:-1]
        newsents = []
        for sent in sents:
            newsents.append(sentence(sent,self))
        return newsents

            
    def genSentPairs(self,sents):
        sents.append(None)
        return zip(sents[::2], sents[1::2])
 
def getIDF(sents):
    tokenToDocs = defaultdict(list)
    umlsToDocs = defaultdict(list)
    wikiToDocs = defaultdict(list)
    for sent in sents:
        for token in sent.tokens:
            tokenToDocs[token].append(sent.id)
        for umlsTerm in sent.UMLSterms:
            umlsToDocs[umlsTerm].append(sent.id)
        for wikiTerm in sent.WIKIterms:
            wikiToDocs[wikiTerm].append(sent.id)
    (wikiIDF,umlsIDF,tokensIDF) = ({},{},{})
    for token in tokenToDocs.keys():
        tokensIDF[token] = len(set(tokenToDocs[token]))
    for umlsTerm in umlsToDocs.keys():
        umlsIDF[umlsTerm] = len(set(umlsToDocs[umlsTerm]))
    for wikiTerm in wikiToDocs.keys():
        wikiIDF[wikiTerm] = len(set(wikiToDocs[wikiTerm]))
    return (wikiIDF,umlsIDF,tokensIDF)
      
def createSentsIDDict(sents,oldSentsDict):
    sentsIDDict =oldSentsDict
    for sent in sents:
        sentsIDDict[sent.id] = sent
    return sentsIDDict

def getSolrServer(topic):
    print '$$$$$$$$$$$$$$$$$$$$' +topic
    if topic is 'cancer':
        return 'http://www.cs.bgu.ac.il/~talbau/solrcancer/'
    if topic is 'asthma':
        return 'http://www.cs.bgu.ac.il/~talbau/solr/'
    if topic is 'alz':
        return 'http://www.cs.bgu.ac.il/~talbau/solralz/'
    return 'http://www.cs.bgu.ac.il/~talbau/solrobese/'
def addNode(g,s,idfs,oldSentsDict,a,b):
    g.add_node(s.id)
    for node in g.nodes():
        score = simScore(s,oldSentsDict[node],idfs,a,b)
        g.add_edge(s.id, node, weight = score)
        score = simScore(oldSentsDict[node],s,idfs,a,b)
        g.add_edge(node, s.id, weight = score)
    return g

def printStats(g,sentDict):
    print 'number of nodes is: ' + str(len(g.nodes()))
    print 'number of edges is: ' + str(len(g.edges()))
    print 'average weight is: ' + str(numpy.mean(map(lambda e : e[2]['weight'],g.edges(data = True))))
    tokensSet = []
    wikiTermsSet = []
    umlsSet = []
    for sent in sentDict.values():
        tokensSet += sent.tokens
        wikiTermsSet += sent.WIKIterms
        umlsSet += sent.UMLSterms
    print 'number of tokens found is: ' + str(len(tokensSet))
    print 'number of unique tokens found is: ' + str(len(set(tokensSet)))
    print 'number of wiki terms found is: ' + str(len(wikiTermsSet))
    print 'number of unique wiki terms found is: ' + str(len(set(wikiTermsSet)))
    print 'number of UNLS terms found is: ' + str(len(umlsSet))
    print 'number of unique UMLS terms found is: ' + str(len(set(umlsSet)))
    
def addRelavantNodes(g,oldSentsDict,quary,topic,a = 0,b = 0):
    solrServer = getSolrServer(topic)
    sents = fetchDocs(solrServer,quary.lexical)
    sents = filter(lambda s: not s.id in oldSentsDict.keys(),sents)
    sents.append(quary)
    sentDict = createSentsIDDict(sents,oldSentsDict)
    idfs = getIDF(sentDict.values())
    print 'creating graph'
    for (i,s) in enumerate(sents):
        if i%20 == 0:
            print 'added node number: ' +str(i) 
            sys.stdout.flush()
        g = addNode(g,s,idfs,oldSentsDict,a,b)
    printStats(g,sentDict)
    return (g,sentDict,idfs)
    
    
    