from buildGraph import addRelavantNodes,Doc
import summ
import writeSum
import time
import networkx as nx
import nltk
import sys
from scoring import *

def writetofile(best):    
	for sent in best:
		print sent.lexical
            
def sentenceFactory(q,sentid):
    q = q.replace("\'","\\\'").replace("\"","\\\"").replace('\\','').encode('ASCII')
    hit = {}
    hit['id'] = str(sentid)
    hit['title']='q'
    hit['text']= [q+'newlinE'+hit['id']+'newlinE']
    q = Doc(hit).sents[0]
    return q

def getQueries(topic,batch):
    counter = 0
    with open(topic+'/queries.txt') as f:
        for line in f:
            line = line.strip()
            counter += 1
            if (counter == batch):
                return line.split('|')
  

def main(topic, chain):  
	a = 0.0 #wikiterms weight
	b = 0.0 #UMLS terms weight
	d = 0.95 #influance of the quary
	treshold = 1.4 #similarity treshold
	g = nx.DiGraph()
	sentDict = {}
	prevQueries = []
	prevSumms = []
	chain = chain.strip()
	for (i,q) in enumerate(chain.split('|')):
		print q
		g = nx.DiGraph()
		sentDict = {}
		prevQueries = []
		prevSumms = []
		sys.stdout.flush()
		q = sentenceFactory(q,-len(prevQueries))
		(g,sentDict,idfs) = addRelavantNodes(g,sentDict,q,topic,a,b)
		g = summ.normalizeGraph(g)
		rank = summ.getrank(g)
		summary = writeSum.get(rank,250,prevSumms,sentDict,treshold,idfs,a,b,q)
		prevSumms.append(summary)
		prevQueries.append(q)
		writetofile(summary)
		sys.stdout.flush()


