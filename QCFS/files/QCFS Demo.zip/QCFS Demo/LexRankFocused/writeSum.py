
from scoring import simScore

def isSimilar(sent,summ,prevSumms,simTreshold,idfs,a,b):
    for othersent in summ: 
        if simScore(sent,othersent,idfs,a,b) > simTreshold: return True
    for otherSumm in prevSumms:
        for  othersent in otherSumm:
            if simScore(sent,othersent,idfs,a,b) > simTreshold: return True
    return False

def countsum(summ):
    count = 0
    for sent in summ: count += len(sent.lexical.split())
    return count


def getbest(sortedsenteces,prevSumms,sentsIDDict,maxwordcount,simTreshold,idfs,a,b,query):
    summ = []
    for sentid in sortedsenteces:
        if countsum(summ) > maxwordcount: return summ
        sent =  sentsIDDict[sentid]
        if not isSimilar(sent,summ,prevSumms,simTreshold,idfs,a,b): 
            summ.append(sent)
    return summ


def get(rank,maxwordcount,prevSumms,sentsIDDict,simTreshold,idfs,a,b,query):
    maxwordcount = 250
    
    #(wikiIDF,umlsIDF,tokensIDF) = pickle.load(open(folder+'/idfs.pkl'))
    sortedsenteces = sorted(rank.keys(), key=lambda k: rank[k])
    sortedsenteces.reverse()
    best = getbest(sortedsenteces,prevSumms,sentsIDDict,maxwordcount,simTreshold,idfs,a,b,query)
    return best