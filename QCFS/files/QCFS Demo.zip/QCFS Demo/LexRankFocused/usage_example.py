import wiki
import UMLS


s1 = 'i like mold'
s2 = 'i have asthma'
print wiki.tools.wikify(s1)
print wiki.tools.wikify(s2)
print UMLS.tools.tagUMLS(s1)
print UMLS.tools.tagUMLS(s2)
print wiki.tools.compare(wiki.tools.wikify(s1)[0],wiki.tools.wikify(s2)[0])
print UMLS.tools.compare(UMLS.tools.tagUMLS(s2)[0],UMLS.tools.tagUMLS(s1)[0])
wiki.tools.saveDicts()
UMLS.tools.saveDicts()