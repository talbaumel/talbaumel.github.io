import sys
sys.path.append("../solr related")
from genTopicsAndSites import genSitesAndTopics

def genSubmitCode(user,currentQ,nextq):
    output = "onSubmit(\'"+str(user.name)+"\',"+str(currentQ)+","+str(nextq)+");"
    return output
    
def genHTML(user,currentQ):
    templatefile = open("summsite.html","r")
    output = ""
    for line in templatefile:
        output += line
    output = output.replace("%currentquery%", user.getQuery(currentQ))
    (siteFacets,topicFacets) = genSitesAndTopics()
    output = output.replace("%sitefacets%", str(siteFacets))
    output = output.replace("%topicfacets%", str(topicFacets))
    
    if currentQ == 0:
        output = output.replace("%isFirst%","class=\"btn disabled\"")
    else:
        output = output.replace("%isFirst%","class=\"btn\" onclick=\"%prevcode%\"")
    output = output.replace("%prevcode%", str(genSubmitCode(user,currentQ,currentQ-1)))
    output = output.replace("%savecode%", str(genSubmitCode(user,currentQ,currentQ)))
    output = output.replace("%nextcode%", str(genSubmitCode(user,currentQ,currentQ+1)))
    if currentQ in user.sums.keys():
        output = output.replace("%sum%",user.sums[currentQ][0])
        toggle = ""
        for sentid in user.sums[currentQ][1].split(" "):
            toggle += str(sentid) + ","
            
        output = output.replace("%toggle%",toggle[:-1])

        
    else:
        output = output.replace("%sum%","")
        output = output.replace("%toggle%","")
    
    
    return output
def genHTMLendDoc(user,currentQ):
    templatefile = open("endscreen.html","r")
    output = ""
    for line in templatefile:
        output += line
    output = output.replace("%prevcode%", str('window.location = "summSite/?userName='+user.name+'&currentQ='+str(currentQ-1)+'"'))
    output = output.replace("%usrname%", str(user.name));
    return output
    