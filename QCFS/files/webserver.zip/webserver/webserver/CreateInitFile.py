import solr

class Doc:
    def __init__(self,hit):
        self.id = str(hit['id'])
        self.title = str(hit['title'][0])
        sents = (str(hit['text'][0])).split("newlinE")
        self.sents = [sent.replace("\'","\\\'").replace("\"","\\\"").encode('ASCII') for sent in sents]
        
        
    def genSentPairs(self):
        sents = self.sents
        sents.append(None)
        return zip(sents[::2], sents[1::2])
        
    def getInitCode(self):
        
        out = 'docs['+self.id+'] = '+str(self.sents) + ';\n'
        out += "docidtoname["+self.id+"] = \""+self.title+"\";\n"
        sentPairs = self.genSentPairs()
        for p in sentPairs:
            if p[1]:
                line = p[0]
                lineid = p[1]
                out += "idToSentece["+lineid+"] = \""+line+"\";\n"
                out += "senidtodocid["+lineid+"] = \""+self.id+"\";\n"
        
        return out  
        
        
        
        
def createInitFile():
    docs = requestAllDocs()
    output = ["function initall(){\n"]
    for doc in docs:
        output.append(doc.getInitCode())
    output.append("}")
    writeInitFile(output)
    
def writeInitFile(output):
    fp = open('static/init.js','w')
    for line in output:
        fp.write(line)
    fp.close()
    
    
def requestAllDocs():
    s = solr.SolrConnection('http://www.cs.bgu.ac.il/~talbau/solr/')
    start = 0
    docs = []
    response = s.query('*:*',start = start)
    while response:
        for hit in response.results:
            docs.append(Doc(hit))
        start += 10
        response = s.query('*:*',start = start)
    
    return docs