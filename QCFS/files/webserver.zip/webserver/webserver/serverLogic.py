import os
from os import path, access, R_OK
import pickle
from HTMLgenerator import genHTML,genHTMLendDoc

def save(userName):
    user = getUser(userName)
    user.saveSum()
    user.save()
    return


def getUser(userName):
    userFile = str("data/users/"+userName+".p")
    if path.exists(userFile) and path.isfile(userFile) and access(userFile, R_OK):
        user =  pickle.load( open( userFile, "rb" ) )
    else:
        user = User(userName)
        open(userFile, 'w').close()
        pickle.dump( user, open( userFile, "wb" ) )
    return user

def handlePOST(sents,Summary,userName,currentQ):
    user = getUser(userName)
    user.sums[currentQ] = (Summary,sents)
    user.save()
    
def handleGET(userName,currentQ):
    user = getUser(userName)
    if len(user.session[1]) > currentQ:
        return genHTML(user,currentQ)
    else:
        return genHTMLendDoc(user,currentQ)
    
class User:
    def __init__(self,name):
        self.name = name #name of the user
        self.sums = {} #queryid = (summry,sentenceslist)
        self.previousSessions = [] #list of ids
        self.session = srv.assignSession(self.previousSessions)#id list
        
    def getQuery(self,currentQ):
        return self.session[1][int(str(currentQ))]
    def saveSum(self):
        sessionFile = "data/sums/"+str(self.session[0])+"/"+self.name+".p"
        fp = open( sessionFile, "wb" )
        pickle.dump( self.sums,  fp)
        self.previousSessions.append(int(self.session[0]))
        self.sums = {}
        self.session = srv.assignSession(self.previousSessions)#id list
        
    def save(self):
        userFile = str("data/users/"+self.name+".p")
        pickle.dump( self, open( userFile, "wb" ) )

class Server:
    def __init__(self):
        self.queries = self.readQueries("queries.txt") #list(queries,count)
        
    def assignSession(self,previousSessions):
        for q in self.queries:
            if not int(q[0]) in previousSessions:
                return (q[0],q[1])


    def countSumms(self,i):
        path = "data/sums/"+str(i)
        count = 0
        if not os.path.exists(path):
            os.makedirs(path)
        for f in os.listdir(path):
            if not f.startswith("."):
                count += 1
        return count
    def readQueries(self,queriesFile):
        fp = open(queriesFile,"r")
        queries = []
        i = 0
        for line in fp:
            count = self.countSumms(i)
            i += 1
            queries.append((i,line.split("|"),count))
        fp.close()
        return queries

def initServer():
    global srv
    srv = Server()