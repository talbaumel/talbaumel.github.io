import os
from HTMLgenerator import genHTML

uid = 0
def getUID():
    global uid 
    uid += 1
    return str(uid)
sessions = []

def findSession(sessionid):
    for s in sessions:
        if s.id == sessionid:
            return s

def handlePOST(sents,Summary,sessionid,quarrynum):
    #sessionid = request.form["sessionid"]
    #qnum = request.form["qnum"]
    #summ = request.form["summ"]
    currentsession = findSession(sessionid)       
    currentsession.addSummary(sents, Summary,quarrynum)
           
def handleGET(sessionID,currentQ):
    if sessionID == "0":
        currentsession = session(getUID())
        sessions.append(currentsession)
    else:
        currentsession = findSession(sessionID)
    if len(currentsession.query) <= int(currentQ):
        currentsession.endSession()
        return "Thank You :D\n" + str(len(currentsession.summs))
    return genHTML(currentsession,currentQ)

def getMinQuerie(queries):
    m = 1000
    worst = None
    for query in queries:
        if m > query[2]:
            m = query[2]
            worst = query
    queries.remove(worst)
    queries.append((worst[0],worst[1],worst[2]))
    return worst

class session:
    def __init__(self,sessionid):
        queries = readQueries("queries.txt")
        self.id = sessionid
        query = getMinQuerie(queries)
        self.queryID = query[0]
        self.query = query[1]
        self.queryCount = query[2]
        self.summs = []
        
    
    def getQuery(self,i):
        return self.query[int(i)]
    
    def isExist(self,i):
        return len(self.query) <= i
    
    def addSummary(self,sents, Summary,quarrynum):
        self.summs.append((sents, Summary,quarrynum))
        
    def endSession(self):
        i = self.queryID
        path = "sums/" + str(i) +"/"+ str(countSumms(i)+1)
        fp = open(path,"w")
        for summ in self.summs:
            fp.write(summ[1])
            fp.write("\n----\n")
        fp.close()
        
    
def countSumms(i):
    path = "sums/"+str(i)
    count = 0
    if not os.path.exists(path):
        os.makedirs(path)
    for f in os.listdir(path):
        if not f.startswith("."):
            count += 1
    return count
            
def readQueries(queriesFile):
    fp = open(queriesFile,"r")
    queries = []
    i = 0
    for line in fp:
        count = countSumms(i)
        i += 1
        queries.append((i,line.split("|"),count))
    fp.close()
    return queries