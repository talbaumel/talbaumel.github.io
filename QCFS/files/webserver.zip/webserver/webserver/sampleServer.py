from flask import Flask, url_for, request, send_file
from serverLogic import initServer,handlePOST,handleGET,save
from CreateInitFile import createInitFile
app = Flask(__name__)

@app.route('/summSite/', methods =  ['POST','GET'])
def summSite():
    print request.method
    if request.method == 'GET':
        userName = str(request.args.get('userName',''))
        currentQ = int(str(request.args.get('currentQ','')))
        return handleGET(userName,currentQ)
    else:
        
        sents = request.form['sents']
        Summary = str(request.form['Summary'])
        userName = str(request.form['userName'])
        currentQ = int(str(request.form['currentQ']))
        nextQ = int(str(request.form['nextQ']))
        
        handlePOST(sents,Summary,userName,currentQ)
        return handleGET(userName,nextQ) 

@app.route('/save/', methods =  ['POST','GET'])
def savesumm():
    if request.method == 'GET':
        return ""
    userName = str(request.form['userName'])
    save(userName)
    return "<meta HTTP-EQUIV=\"REFRESH\" content=\"0; url=http://www.cs.bgu.ac.il/~talbau/static/login.html\">"

@app.route('/summSite/images/ajax-loader.gif')
def getImage():
    return send_file("static/ajax-loader.gif", mimetype='image/gif') 

if __name__== '__main__':
    createInitFile()
    
    initServer()
    app.run(host = '0.0.0.0',debug = True)