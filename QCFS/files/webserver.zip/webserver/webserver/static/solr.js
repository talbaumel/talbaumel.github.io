var Manager;
var first = true;
var docs = new Object();
var isSentenceSelected = new Object();
var idToSentece = new Object();
var senidtodocid = new Object();
var docidtoname = new Object();
var topic = "None";
var site = "None";
(function ($) {

  $(function () {
	initall();
    Manager = new AjaxSolr.Manager({
      solrUrl: 'http://www.cs.bgu.ac.il/~talbau/solr/'
    });
    Manager.addWidget(new AjaxSolr.ResultWidget({
      id: 'result',
      target: '#docs'
    }));
    Manager.addWidget(new AjaxSolr.PagerWidget({
      id: 'pager',
      target: '#pager',
      prevLabel: '&lt;',
      nextLabel: '&gt;',
      innerWindow: 1,
      renderHeader: function (perPage, offset, total) {
        //$('#pager-header').html($('<span/>').text('displaying ' + Math.min(total, offset + 1) + ' to ' + Math.min(total, offset + perPage) + ' of ' + total));
      }
    }));
    Manager.init();
    Manager.store.addByValue('q', '*:*');
	var params = {
      //facet: true,
      //'facet.field': [ 'topics', 'organisations', 'exchanges' ],
      //'facet.limit': 20,
      //'facet.mincount': 1,
      //'f.topics.facet.limit': 50,
      'json.nl': 'map'
    };
    for (var name in params) {
      Manager.store.addByValue(name, params[name]);
    }
    Manager.doRequest();
    countWords();
  });

})(jQuery);
function handleKeyPress(e,form){
	var key=e.keyCode || e.which;
	if (key==13){
		runSearch();
	}
}
function runSearch(){
	Manager.store.remove('fq');
	var userQuery;
	userQuery = document.getElementById("query").value;
	if (userQuery==""){
		userQuery = '*:*';
	}
	Manager.store.addByValue('q', userQuery);
	
	Manager.store.addByValue('facet', 'true');
	if (site != "None"){
		Manager.store.addByValue('fq', 'site:' + site);
	}
	if (topic != "None"){
		Manager.store.addByValue('fq', 'topic:' + topic);
	}
    Manager.doRequest();
}
function genSenteces(id){
	//alert(docidtoname[id]);
	$("#selecteddoc").empty();
	$("#selecteddoc").append("Selected Document: "+docidtoname[id]);
	$('#setnteces').empty();
	var text = docs[id];
	for (var i=0;i<text.length-1;i+=2){
		var line =  text[i];
		var lineid = text[i+1];
		var lineNum = (i/2)+1;
		idToSentece[lineid] = line;
		senidtodocid[lineid] = id;
		if (!isSentenceSelected[lineid]){
			$('#setnteces').append("<span class=\"badge\" onclick={toggleSent(\""+lineid+"\");}>" + lineNum.toString() + "</span>" + line + "<br/>");
		}
		else{
			$('#setnteces').append("<span class=\"badge badge-success\" onclick={toggleSent(\""+lineid+"\");}>" + lineNum.toString() + "</span>" + line + "<br/>");
		}
		
	}
}
function toggleSent(senid) {
	
	docid = senidtodocid[senid]
	isSentenceSelected[senid] = !isSentenceSelected[senid];
	genSenteces(docid);
	writeSelectedSenteces();
}
function toggleList(sentsids,sentstext,docids) {
	for (var i in sentsids){
		isSentenceSelected[sentsids[i]] = true;
	}
	writeSelectedSenteces();
}
function writeSelectedSenteces(){
	$('#selected').empty();
	var i = 1;
	for (var id in isSentenceSelected){
		if (isSentenceSelected[id]){
			var line = idToSentece[id];
			var docid = senidtodocid[id];
			line = line.replace("\"","");
			line = line.replace("\'","");
			$('#selected').append(line +"<br>");
			$('#selected').append("<span class=\"badge badge-important\" onclick={toggleSent(\""+id+"\");}>  Remove </span>");



            
			$('#selected').append("<span class=\"badge label-warning\" onclick = {genSenteces(\""+docid+"\");} title=\""+docidtoname[docid]+"\"> Show Source </span>");
			$('#selected').append("<span class=\"badge label-info\" onclick = {appendToSumm(\""+id+"\");}> Copy </span>");
			$('#selected').append("<br/><br/>");
			i++;
		}
	}
}
function appendToSumm(id) {
	line = idToSentece[id];
	Summary.value += " ";
	Summary.value += line;
	countWords();
}

function onSubmit(userName,currentQ,next) {
	
	sendQuarry(userName,currentQ,next);

}
function sendQuarry(userName,quarrynum,next) {
	var sents= "";
	for (var sent in isSentenceSelected){
		if (isSentenceSelected[sent])
			sents = sents + sent + " ";
	}
	post_to_url('http://www.cs.bgu.ac.il/~talbau/summSite/?userName='+userName+'&currentQ='+next, {'sents':sents,'Summary':Summary.value,'userName':userName,'currentQ':quarrynum,'nextQ':next},"POST");
}
function post_to_url(path, params, method) {
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);

    for(var key in params) {
        if(params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);

            form.appendChild(hiddenField);
         }
    }

    document.body.appendChild(form);
    form.submit();
}
function login() {

	var userName = document.getElementById('Emailbox').value;
	window.location.href='http://www.cs.bgu.ac.il/~talbau/summSite/?userName='+userName+'&currentQ=0';
}
function login2() {

	var userName = document.getElementById('Emailbox').value;
	window.location.href='http://www.cs.bgu.ac.il/~talbau/summSite2/?userName='+userName+'&currentQ=0';
}

function countWords() {
	var words = Summary.value.split(" ");
	var count = 0;
	for(var s in words ) {
		if (words[s].length > 0) {
			count = count + 1;
		}
	}
	counter.innerText=count.toString()+'/250';
}

function endSession(userName){
	post_to_url('http://www.cs.bgu.ac.il/~talbau/save/',{'userName':userName},"POST");
}
$(function() {
  $('a#helptrigger').hover(function(e) {
    $('div#pop-up').show()
      .css('top', e.pageY)
      .css('left', e.pageX)
      .appendTo('body');
  }, function() {
    $('div#pop-up').hide();
  });
});